package lesson3.label2.constants;

public class LabelConstants {
	public static final int LEFT = 0;
	public static final int CENTER = 1;
	public static final int RIGHT = 2;
	
}
