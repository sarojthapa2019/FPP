MyEnum is a Java 4 implementation of the enum concept (before
Java had created an enum type)