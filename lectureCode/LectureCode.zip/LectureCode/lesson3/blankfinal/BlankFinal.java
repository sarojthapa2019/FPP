package lesson3.blankfinal;

public class BlankFinal {
	final int blankFinal;
	
	//cannot do this because it's static
	//static final int another;
	
	public BlankFinal() {
		blankFinal = 3;
	}

}
