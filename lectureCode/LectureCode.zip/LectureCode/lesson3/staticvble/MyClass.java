package lesson3.staticvble;

public class MyClass {
	static int x = 1;
	public MyClass(int s) {
		x = s;
	}
}
