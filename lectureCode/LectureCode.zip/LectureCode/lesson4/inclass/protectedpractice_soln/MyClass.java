package lesson4.inclass.protectedpractice_soln;

public class MyClass extends MySuperClass {
	@Override
	public String getVal() {
		return super.getVal();
	}
}
