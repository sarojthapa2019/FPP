package lesson4.exercise_5.nested;

import lesson4.exercise_5.MyClass;

public class CallingClass {
	public String readVal() {
		MyClass cl = new MyClass();
		return cl.getVal();
	}
}
