package lesson7.exercise_1;

public class PersonLine {
	private Person[] personLine;
	PersonLine(Person[] persons) {
		personLine = persons;
	}
	/** The number of people in line is the 1 + the number
	 *  of people behind person_0 
	 */
	public int howManyInLine() {
		return personLine[0].answerToQuestion() + 1;
	}
}


