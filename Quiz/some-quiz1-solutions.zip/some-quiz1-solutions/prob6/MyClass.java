package quiz1.prob6;

public class MyClass {
	public static void main(String[] args) {
		AnotherClass a = new AnotherClass(new MyClass());
		a.anotherMethod();
	}
	void myMethod() {
		System.out.println("hello");
	}
}

class AnotherClass {
	MyClass m;
	AnotherClass(MyClass m) {
		this.m = m;
		anotherMethod();
	}
	void anotherMethod() {
		m.myMethod();
	}
		
}

