package quiz2.prob10;

public class AccountType {
	static AccountType instance = new AccountType();
	static AccountType CHECKING = instance.new CHECKING();
	static AccountType SAVINGS = instance.new SAVINGS();
	static AccountType RETIREMENT = instance.new RETIREMENT();
		
	private AccountType(){}
	
	private class CHECKING extends AccountType {
		
	}
	private class SAVINGS extends AccountType{}
	private class RETIREMENT extends AccountType{}
}
