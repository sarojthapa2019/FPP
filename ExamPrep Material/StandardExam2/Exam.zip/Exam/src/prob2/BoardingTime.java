package prob2;

public interface BoardingTime {

}
