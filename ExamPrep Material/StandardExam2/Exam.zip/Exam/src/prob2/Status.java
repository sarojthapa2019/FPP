package prob2;

public enum Status {

	 GOLD, SILVER, PLATINUM;
}
