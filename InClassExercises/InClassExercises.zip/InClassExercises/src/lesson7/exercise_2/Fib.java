package lesson7.exercise_2;

public class Fib {
	
	public int fib(int n) {
		//implement
		return 0;
		
	}	
	
	public static void main(String[] args) {
		Fib f = new Fib();
		System.out.println(f.fib(10));
		
	}
}


